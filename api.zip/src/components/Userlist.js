import axios, { Axios } from 'axios'
import React from 'react'
import { useState ,useEffect  } from 'react';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';


function Userlist() {
    
const [users, setusers] = useState([]);
    useEffect(() => {
        try {
            axios.get("https://jsonplaceholder.typicode.com/users").then ((res)=>setusers(res.data)) 
        } catch (error) {
            
        }
        
},[])
  return (
    <div className="box">
        {users.map((el)=>
            <Card   style={{ width: '12rem' }}>
            <Card.Body className="box1">
              <Card.Title id="name">{el.name}</Card.Title>
              <Card.Text id="namee">
                <h1 id="namee">  {el.username}</h1>
              </Card.Text>
              <p id="name2"> {el.email}</p>
              
              <Button id="hello" variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
        )}
    </div>
  )
}

export default Userlist 