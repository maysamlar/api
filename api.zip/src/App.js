import logo from './logo.svg';
import './App.css';
import Userlist from './components/Userlist';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div >
   <Userlist/>
    </div>
  );
}

export default App;
